/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zgsu3t0mgv1znn5")

  collection.indexes = [
    "CREATE INDEX `idx_wPJBKcB` ON `tools_designs` (`_id`)",
    "CREATE INDEX `idx_9s7sNb2` ON `tools_designs` (`parentid`)",
    "CREATE INDEX `idx_bc1Wsb2` ON `tools_designs` (`componentactive`)",
    "CREATE UNIQUE INDEX `idx_b8MZzTa` ON `tools_designs` (`name`)"
  ]

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zgsu3t0mgv1znn5")

  collection.indexes = [
    "CREATE INDEX `idx_wPJBKcB` ON `tools_designs` (`_id`)",
    "CREATE INDEX `idx_9s7sNb2` ON `tools_designs` (`parentid`)",
    "CREATE INDEX `idx_bc1Wsb2` ON `tools_designs` (`componentactive`)",
    "CREATE INDEX `idx_b8MZzTa` ON `tools_designs` (`name`)"
  ]

  return dao.saveCollection(collection)
})
