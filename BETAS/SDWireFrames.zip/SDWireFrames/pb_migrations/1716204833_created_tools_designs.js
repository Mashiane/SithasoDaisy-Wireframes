/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const collection = new Collection({
    "id": "zgsu3t0mgv1znn5",
    "created": "2024-05-20 11:33:53.013Z",
    "updated": "2024-05-20 11:33:53.013Z",
    "name": "tools_designs",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "bwtec60t",
        "name": "parentid",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "a3nqiwl4",
        "name": "name",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "zorldtbf",
        "name": "componenttype",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "dsl5avxq",
        "name": "parentdevice",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "qem7roig",
        "name": "_id",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "said4wgh",
        "name": "componentactive",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "5ydl2kfz",
        "name": "properties",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "indexes": [
      "CREATE INDEX `idx_wPJBKcB` ON `tools_designs` (`_id`)",
      "CREATE INDEX `idx_9s7sNb2` ON `tools_designs` (`parentid`)",
      "CREATE INDEX `idx_bc1Wsb2` ON `tools_designs` (`componentactive`)",
      "CREATE INDEX `idx_b8MZzTa` ON `tools_designs` (`name`)"
    ],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("zgsu3t0mgv1znn5");

  return dao.deleteCollection(collection);
})
