/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const collection = new Collection({
    "id": "fohkh1tz2cln1fd",
    "created": "2024-05-20 11:33:53.013Z",
    "updated": "2024-05-20 11:33:53.013Z",
    "name": "tools_files",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "ywuslhyi",
        "name": "file",
        "type": "file",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "mimeTypes": [],
          "thumbs": [],
          "maxSelect": 1,
          "maxSize": 5242880,
          "protected": false
        }
      },
      {
        "system": false,
        "id": "s2qf0aga",
        "name": "filename",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "rsgi96te",
        "name": "filetype",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "indexes": [
      "CREATE INDEX `idx_TOzPJJI` ON `tools_files` (`filename`)",
      "CREATE INDEX `idx_G5qnEJh` ON `tools_files` (`filetype`)"
    ],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("fohkh1tz2cln1fd");

  return dao.deleteCollection(collection);
})
