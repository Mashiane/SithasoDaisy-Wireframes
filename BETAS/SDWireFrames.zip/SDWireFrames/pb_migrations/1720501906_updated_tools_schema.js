/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("mcjnxp7uc9y1sa9")

  collection.indexes = [
    "CREATE INDEX `idx_WcSXf14` ON `tools_schema` (`pagename`)",
    "CREATE INDEX `idx_cOx3yGT` ON `tools_schema` (`componentname`)",
    "CREATE INDEX `idx_F4h165f` ON `tools_schema` (`tablename`)",
    "CREATE INDEX `idx_uGeiI7c` ON `tools_schema` (`fieldname`)",
    "CREATE INDEX `idx_jaDraER` ON `tools_schema` (`active`)"
  ]

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("mcjnxp7uc9y1sa9")

  collection.indexes = [
    "CREATE INDEX `idx_WcSXf14` ON `tools_schema` (`pagename`)",
    "CREATE INDEX `idx_cOx3yGT` ON `tools_schema` (`componentname`)",
    "CREATE INDEX `idx_F4h165f` ON `tools_schema` (`tablename`)",
    "CREATE INDEX `idx_uGeiI7c` ON `tools_schema` (`fieldname`)"
  ]

  return dao.saveCollection(collection)
})
