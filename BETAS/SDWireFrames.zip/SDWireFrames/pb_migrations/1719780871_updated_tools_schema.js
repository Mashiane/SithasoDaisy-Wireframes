/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("mcjnxp7uc9y1sa9")

  collection.indexes = [
    "CREATE INDEX `idx_WcSXf14` ON `tools_schema` (`pagename`)"
  ]

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("mcjnxp7uc9y1sa9")

  collection.indexes = []

  return dao.saveCollection(collection)
})
